<?php
class Login_mod extends CI_Model
{

	function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	function getNIK()
    {
        //$this->db->where('email', );
    }
}
